#importing modules
import pygame
import time
from time import sleep

#defining reoccurring variables
WINWIDTH=1000
WINHEIGHT=600
RECTHEIGHT=150
RECTWIDTH=100
FIGHTERSY=350
FIGHTER1X=100
FIGHTER2X=800
BARWIDTH=400
BARHEIGHT=20
FIGHTER1HEIGHT=RECTHEIGHT * 3
FIGHTER2HEIGHT=RECTHEIGHT*5
FIGHTER1WIDTH=RECTWIDTH * 3
FIGHTER2WIDTH=RECTWIDTH *6

#class for fighters, where variables are accessable
# idea of classes came from https://www.youtube.com/watch?v=rJzjDszODTI
class fighters:
    def __init__(self,player,x,y,healthx,fighterimg,height,width,drawx,drawy,fighterimgdead):
        self.player=player
        self.x=x
        self.y=y
        self.rect= pygame.Rect(self.x, self.y, RECTWIDTH, RECTHEIGHT)
        self.fighter=0
        self.health=100
        self.healthx=healthx
        self.jump=False
        self.attack = False
        self.run= False
        self.hit=False
        self.flip=False
        self.height = RECTHEIGHT * height
        self.width=RECTWIDTH*width
        self.drawx=drawx
        self.drawy=drawy
        self.fighterimg=fighterimg
        self.fighterimgdead=fighterimgdead
        self.image=pygame.transform.scale(self.fighterimg, (self.width , self.height))
        self.imagedead=pygame.transform.scale(self.fighterimg, (self.width , self.height))
        self.alive=True
        self.roundover=False
        self.idle = True

    #fuction to draw the fighters and their various states
    # commands to change, load and readjust came from https://www.pygame.org/docs/ref/surface.html
    def drawfighters(self, surface,player):
        #self.rect = pygame.draw.rect(surface, [255, 255, 255], pygame.Rect(self.x, self.y, RECTWIDTH, RECTHEIGHT))

        #the first players pictures
        if self.player==1:
            #load all needed images
            fighter1attack1 = pygame.image.load('Attack1.png')
            fighter1death = pygame.image.load('Death.png')
            fighter1idle = pygame.image.load('Idle.png')
            fighter1run = pygame.image.load('Run.png')
            fighter1takehit = pygame.image.load('Take Hit.png')
            if self.run == True:
                self.idle == False
                if self.flip == False and self.jump == False and self.hit == False:
                    self.rect = surface.blit(pygame.transform.scale(fighter1run, (self.width, self.height)),
                                            (self.x - self.drawx, self.y - self.drawy))
                if self.flip == True and self.jump == False and self.hit == False:
                    self.rect = pygame.transform.flip(fighter1run, True, False)
                    surface.blit(pygame.transform.scale(self.rect, (self.width, self.height)),
                                 (self.x - self.drawx, self.y - self.drawy))
                # jump
            if self.jump == True:
                if self.flip == False:
                    self.rect = surface.blit(pygame.transform.scale(fighter1idle, (self.width, self.height)),
                                            (self.x - self.drawx, self.y - self.drawy))
                if self.flip == True:
                    self.rect= pygame.transform.flip(fighter1idle, True, False)
                    surface.blit(pygame.transform.scale(self.rect, (self.width, self.height)),
                                 (self.x - self.drawx, self.y - self.drawy))
                # attack
            if self.attack == True and self.run == False:
                self.idle == False
                if self.flip == False:
                    self.rect = surface.blit(pygame.transform.scale(fighter1attack1, (self.width, self.height)),
                                            (self.x - self.drawx, self.y - self.drawy))
                if self.flip == True:
                    flipped = pygame.transform.flip(fighter1attack1, True, False)
                    surface.blit(pygame.transform.scale(flipped, (self.width, self.height)),
                                 (self.x - self.drawx, self.y - self.drawy))
                    # death
            if self.alive == False:
                self.idle == False
                self.rect = surface.blit(pygame.transform.scale(fighter1death, (self.width, self.height)),
                                        (self.x - self.drawx, self.y - self.drawy))
                # gets hit
            if self.hit == True and self.alive == True and self.attack==False:
                self.idle == False
                if self.flip == False:
                    self.rect = surface.blit(pygame.transform.scale(fighter1takehit, (self.width, self.height)),
                                            (self.x - self.drawx, self.y - self.drawy))
                if self.flip == True:
                    self.rect = pygame.transform.flip(fighter1takehit, True, False)
                    surface.blit(pygame.transform.scale(flipped, (self.width, self.height)),
                                 (self.x - self.drawx, self.y - self.drawy))
            if self.idle == True and self.attack == False and self.run == False and self.hit == False:
                self.rect = surface.blit(pygame.transform.scale(fighter1idle, (self.width, self.height)),
                                        (self.x - self.drawx, self.y - self.drawy))
            #player 2
        if self.player==2:
            #loading
            fighter2idle = pygame.image.load('f2Idle.png')
            fighter2run = pygame.image.load('f2Run.png')
            fighter2attack1 = pygame.image.load('f2Attack1.png')
            fighter2takehit = pygame.image.load('f2Take hit.png')
            fighter2death=pygame.image.load('f2Death.png')
            #run pictures
            if self.run == True:
                self.idle == False
                if self.flip == False and self.jump == False and self.hit==False:
                    self.rect = surface.blit(pygame.transform.scale(fighter2run, (self.width, self.height)),
                                            (self.x - self.drawx, self.y - self.drawy))
                if self.flip == True and self.jump == False and self.hit==False:
                    self.rect = pygame.transform.flip(fighter2run, True, False)
                    surface.blit(pygame.transform.scale(self.rect, (self.width, self.height)),
                                 (self.x - self.drawx, self.y - self.drawy))
            #jump
            if self.jump == True:
                if self.flip == False:
                    self.rect = surface.blit(pygame.transform.scale(fighter2idle, (self.width, self.height)),
                                            (self.x - self.drawx, self.y - self.drawy))
                if self.flip == True:
                    self.rect = pygame.transform.flip(fighter2idle, True, False)
                    surface.blit(pygame.transform.scale(self.rect, (self.width, self.height)),
                                 (self.x - self.drawx, self.y - self.drawy))
            #attack
            if self.attack == True and self.run==False and self.hit==False:
                self.idle == False
                if self.flip == False:
                    self.rect = surface.blit(pygame.transform.scale(fighter2attack1, (self.width, self.height)),
                                            (self.x - self.drawx, self.y - self.drawy))
                if self.flip == True:
                    self.rect = pygame.transform.flip(fighter2attack1, True, False)
                    surface.blit(pygame.transform.scale(self.rect, (self.width, self.height)),
                                 (self.x - self.drawx, self.y - self.drawy))
                    #death
            if self.alive == False:
                self.idle == False
                self.rect = surface.blit(pygame.transform.scale(fighter2death, (self.width, self.height)),
                                        (self.x - self.drawx, self.y - self.drawy))
                #gets hit
            if self.hit== True and self.alive==True and self.attack==False:
                self.idle == False
                if self.flip == False:
                    self.rect = surface.blit(pygame.transform.scale(fighter2takehit, (self.width, self.height)),
                                            (self.x - self.drawx, self.y - self.drawy))
                if self.flip == True:
                    self.rect = pygame.transform.flip(fighter2takehit, True, False)
                    surface.blit(pygame.transform.scale(self.rect, (self.width, self.height)),
                                 (self.x - self.drawx, self.y - self.drawy))
            if self.idle == True and self.attack==False and self.run==False and self.hit==False:
                self.rect = surface.blit(pygame.transform.scale(fighter2idle, (self.width, self.height)),
                                       (self.x - self.drawx, self.y - self.drawy))






#moving fighters function
    def movefighters(self,target,surface):
        #idea to add a rectangle as an attacking range came from https://www.youtube.com/watch?v=jO6qQDNa2UY&t=1922s
        #attacking range
        attackrect = pygame.Rect(self.x, self.y, RECTWIDTH * 2, RECTHEIGHT)
        down=1
        jump=0
        velocity = 0
        #.get_pressed()  and key control commands were  from https://www.pygame.org/docs/ref/color.html
        k = pygame.key.get_pressed()
        # if the round isn't over
        if self.roundover==False:
            #player one controls
            if self.player == 1:
                if self.alive == True:
                    self.jump = False
                    self.y = FIGHTERSY
                    if pygame.key.get_pressed()!=k[pygame.K_a] or k[pygame.K_d] :
                        self.run==False
                    #left
                    if k[pygame.K_a]:
                        self.x -= 5
                        self.run = True
                        self.flip = True
                        self.hit = False
                     #right
                    if k[pygame.K_d]:
                        self.x += 5
                        self.run = True
                        self.flip = False
                        self.hit = False
                        #jumping
                    if k[pygame.K_w]:
                        if jump == 0 and self.jump == False:
                            self.jump = True
                            velocity = -100
                            self.y += velocity
                            jump += 1
                        if jump >= 1:
                            self.y = FIGHTERSY
                    velocity += down
                    self.y += velocity
                    if k[pygame.K_w] and (k[pygame.K_d] or k[pygame.K_a]):
                        self.y = FIGHTERSY
                    # creating boundaries
                    if self.x < 0:
                        self.x = 1
                    if RECTWIDTH + self.x > WINWIDTH:
                        self.x = WINWIDTH - RECTWIDTH
                    if self.y < 0:
                        self.y = 0
                    if self.y > FIGHTERSY:
                        self.y = FIGHTERSY
                        ##attack
                    if k[pygame.K_r] and self.attack == False :
                        self.attack = True
                        self.run==False
                        if attackrect.colliderect(target):
                            target.healthx += 40
                            target.health -= 10
                            #self.attack = True
                            target.hit = True
                            sleep(0.3)
                            self.attack = False
                            #if target dies
                            if target.health <= 0:
                                target.alive = False
                                self.roundover=True
                        else:
                            sleep(0.3)
                            self.attack = False


                # player2 controls

            if self.player == 2:
                if self.alive == True:
                    self.jump = False
                    self.y = FIGHTERSY
                    # left
                    if k[pygame.K_LEFT]:
                        self.x -= 5
                        self.run = True
                        self.flip = False
                        self.hit = False
                        #right
                    if k[pygame.K_RIGHT]:
                        self.x += 5
                        self.run = True
                        self.flip = True
                        self.hit = False
                        #jumping
                    if k[pygame.K_UP]:
                        if jump == 0:
                            velocity = -100
                            self.y += velocity
                            # self.x+=1
                            jump += 1
                        if jump >= 1:
                            self.y = FIGHTERSY
                    velocity += down
                    self.y += velocity

                    if k[pygame.K_UP] and (k[pygame.K_LEFT] or k[pygame.K_RIGHT]):
                        self.y = FIGHTERSY

                    # creating boundaries
                    if self.x < 0:
                        self.x = 1
                    if RECTWIDTH + self.x > WINWIDTH:
                        self.x = WINWIDTH - RECTWIDTH
                    if self.y < 0:
                        self.y = 0
                    if self.y > FIGHTERSY:
                        self.y = FIGHTERSY
                        #attack
                    if k[pygame.K_0] and self.attack == False:
                        self.attack = True
                        self.run = False
                        if attackrect.colliderect(target):
                            target.healthx -= 40
                            target.health -= 10
                            #self.attack = True
                            target.hit = True
                            sleep(0.3)
                            self.attack = False
                            if target.health <= 0:
                                target.alive = False
                                self.roundover=True
                        else:
                            sleep(0.3)
                            self.attack=False








