#importing modules
import pygame
import sys
import time
from cltrx import fighters
from pygame import mixer


#defining reoccurring variables
WINWIDTH=1000
WINHEIGHT=600
RECTHEIGHT=150
RECTWIDTH=100
FIGHTERSY=350
FIGHTER1X=100
FIGHTER2X=800
BARWIDTH=400
BARHEIGHT=20


##all specified commands are from the website https://www.pygame.org/docs/ref/color.html
#initiating modules
pygame.get_init()
pygame.mixer.init()
pygame.font.init()

#setting up the window
WIN= pygame.display.set_mode((WINWIDTH,WINHEIGHT))
pygame.display.set_caption('Immortal Fire')

#loading the necessary media (photos,audio)
BACKGROUND = pygame.image.load('fighting2.jpg')
BGMUSIC= pygame.mixer.music.load('bgmusic.mp3')

fighter1img= pygame.image.load('Idle.png')
fighter2img=pygame.image.load('f2Idle.png')
fighter1imgd= pygame.image.load('Death.png')
fighter2imgd=pygame.image.load('Death.png')

#came from https://www.youtube.com/watch?v=s5bd9KMSSW4&t=3509s
font = pygame.font.SysFont('Times New Roman',50)
font2= pygame.font.SysFont('Times New Roman',30)
font3= pygame.font.SysFont('Times New Roman',20)



# countdown
#made from the idea of https://www.youtube.com/watch?v=s5bd9KMSSW4&t=3509s
introcount = 3
lastcount = pygame.time.get_ticks()

#Playing background music
pygame.mixer.music.play(start=10.00)
pygame.mixer.music.set_volume(10)



#fuction to draw the background
def drawscreen():
    bg= WIN.blit(pygame.transform.scale(BACKGROUND,(WINWIDTH,WINHEIGHT)),(0,0))
    pygame.draw.rect(WIN, [255, 210, 0], pygame.Rect(5, 10, 200,25))
    render(str('hold space bar for rules'), font3, (0, 0, 0),5,10,font3)
    render(str('PLAYER 1'), font3, (255, 0, 0), 5, 125, font3)
    render(str('PLAYER 2'), font3, (255, 0, 0), 600, 125, font3)

#function to draw the background of the healthbars
def bghealthbars(x,y):
    healthbar=pygame.draw.rect(WIN,[255,255,255], pygame.Rect(x,y, BARWIDTH, BARHEIGHT))

#fuction to draw the healthbars
def healthbars(x,y):
    healthbar=pygame.draw.rect(WIN,[255,0,0], pygame.Rect(x,y, BARWIDTH, BARHEIGHT))

# fuctuíon to  render the text into
def render(self, text, color, y, x,fonts):
    imp = fonts.render(self, text, color)
    WIN.blit(imp, (y, x))

#function to update screen
def update ():
    pygame.display.flip()


## function to show the rules
def rules():
    pygame.draw.rect(WIN, [47,69,83], pygame.Rect(0, 0, WINWIDTH , WINHEIGHT))
    render(str('Rules:'), font, (0,0, 0), 20, 150,font)
    render(str('Player1: to move you need the A,W,D keys '), font, (0, 0, 0), 50, 200,font)
    render(str('to attack use the R key'), font2, (0, 0, 0), 50, 250,font)
    render(str('Player2: to move you need the arrow keys'), font, (0, 0, 0), 50, 300,font)
    render(str('to attack use the 0 Key'), font2, (0, 0, 0), 50, 350,font)

    # create fighters
fighter1 = fighters(1, FIGHTER1X, FIGHTERSY, 0, fighter1img, 3, 3, 70, 150, fighter1imgd)
fighter2 = fighters(2, FIGHTER2X, FIGHTERSY, WINWIDTH - BARWIDTH, fighter2img, 6, 5, 200, 400, fighter2imgd)

    #main game loop
running = True
while running:

#drawing the screen
    #show opening message
    k = pygame.key.get_pressed()
    if k[pygame.K_SPACE]:
        rules()

    else:
        drawscreen()

        # drawing the fighters using the drawfighters' fuction
        fighters.drawfighters(fighter1, WIN, 1)
        fighters.drawfighters(fighter2, WIN, 2)

        # drawing the background healthbars using it's fuction
        bghealthbars(0, 100)
        bghealthbars(WINWIDTH - BARWIDTH, 100)

        # drawing the healthbars
        healthbars(fighter1.healthx, 100)
        healthbars(fighter2.healthx, 100)

        # calling the movefightersfuction
        fighters.movefighters(fighter1, fighter2, WIN)
        fighters.movefighters(fighter2, fighter1, WIN)

        # scoreboard and winner announced
        # if player one wins
        if fighter2.health <= 0:
            #background updated
            drawscreen()
            fighters.drawfighters(fighter1, WIN, 1)
            fighters.drawfighters(fighter2, WIN, 2)
            bghealthbars(0, 100)
            bghealthbars(WINWIDTH - BARWIDTH, 100)

            # healthbars
            healthbars(fighter1.healthx, 100)
            healthbars(fighter2.healthx, 100)
            ### Winner anouncement
            render(str('Player  1 wins'), font, (255, 0, 0), 1000 / 3, 600 / 3,font)
            update()


        # if player 2 wins
        elif fighter1.health <= 0:
            ##screen and background updated
            drawscreen()
            fighters.drawfighters(fighter1, WIN, 1)
            fighters.drawfighters(fighter2, WIN, 2)
            bghealthbars(0, 100)
            bghealthbars(WINWIDTH - BARWIDTH, 100)

            # healthbars
            healthbars(fighter1.healthx, 100)
            healthbars(fighter2.healthx, 100)
            render(str('Player  2 wins'), font, (255, 0, 0), 1000 / 3, 600 / 3,font)


        # updating the screen
    update()


#prompt to close the window
# for loop taken from https://stackoverflow.com/questions/19882415/closing-pygame-window
    for i in pygame.event.get():
        if i.type == pygame.QUIT:
            running = False

#game window closes
pygame.quit()


